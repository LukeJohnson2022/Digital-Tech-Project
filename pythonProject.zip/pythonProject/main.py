print("Welcome to the Climate Change Quiz!")  # Welcoming the user to the quiz

name = ""  # This piece of code, as well as the code below (while name = "":) is used to repeat,
while name == "":  # "What is your name?" if the user leaves the space blank and does not input anything (a loop).
    name = input("What is your name?")  # Telling the program how to find the users name
print("Nice to meet you", name)  # Printing a message to the user, with the users name (found above)

age = int(input("How old are you?"))  # Telling the program how to find the users age


print("Great! Please answer the questions below with the letter next to the answer you would like "
          "to choose (e.g, b)")
# This message is printed to inform the user of how to answer
# the question


from script import Question

question_prompts = [  # The questions in the quiz
    "The last decade was the hottest decade in how many years?\n(a) 25,000\n(b) 100,000\n(c) 125,000\n\n",
    "Carbon Dioxide (CO2) emissions are at its highest in how many years?\n(a) 500,000\n(b) 1,000,000\n(c) 2,000,000\n\n",
    "How many tonnes of ice melts every year due to climate change?\n(a) 1.4 Million\n(b) 1.2 Trillion\n(c) 1.7 Billion\n\n",
    "Since January 1993, how high has the Ocean risen?\n(a) 4 Inches\n(b) 2 Inches\n(c) 6 Inches\n\n",

]

questions = [  # The correct answers of the question prompts
    Question(question_prompts[0], "c"),
    Question(question_prompts[1], "c"),
    Question(question_prompts[2], "b"),
    Question(question_prompts[3], "a")
]


def run_test(questions):  # Runs the question prompts above

    score = 0  # Telling the program that the score starts at 0
    for question in questions:
        answer = input(question.prompt)
        if answer == question.answer:  # Telling the program if the answer is correct, then move on to below
            score += 1  # Telling the program to add one point to the score
    print("You scored " + str(score) + "/" + str(len(questions)) + " questions correct,  "
                                                                   "")  # This tells the user their final score


 # if str(score) <= '2'
  # print("Maybe you should enhance your knowledge with further research")
 # else:                                                                     ## IGNORE - ME TESTING STUFF ##
   # print("-")

run_test(questions)

print("Thank you for partaking in this quiz, Goodbye!")  # End of the quiz
